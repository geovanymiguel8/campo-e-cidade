let xTruck = 50;
let xPlane = 550;
let clouds = [];

function setup() {
  createCanvas(600, 400);

  // Criando nuvens iniciais
  for (let i = 0; i < 5; i++) {
    clouds.push({ x: random(width), y: random(50, 150) });
  }
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Campo
  fill(34, 139, 34);
  rect(0, 250, width / 2, 150);

  // Cidade
  fill(169, 169, 169);
  rect(width / 2, 250, width / 2, 150);

  // Sol
  fill(255, 204, 0);
  ellipse(100, 80, 50, 50);

  // Ponte conectando os dois mundos
  fill(139, 69, 19);
  rect(200, 250, 200, 50);

  // Caminhão trazendo produtos rurais para a cidade
  fill(255, 165, 0);
  rect(xTruck, 275, 50, 25);
  ellipse(xTruck + 5, 300, 15, 15);
  ellipse(xTruck + 45, 300, 15, 15);

  // Avião trazendo tecnologia para o campo
  fill(200, 200, 200);
  ellipse(xPlane, 100, 50, 20);
  triangle(xPlane - 20, 100, xPlane - 40, 90, xPlane - 40, 110);

  // Nuvens no céu
  fill(255);
  for (let i = 0; i < clouds.length; i++) {
    ellipse(clouds[i].x, clouds[i].y, 40, 20);
    clouds[i].x += 0.5;
    if (clouds[i].x > width) clouds[i].x = -40;
  }

  // Movimento dos elementos
  xTruck += 1;
  xPlane -= 1;

  // Resetando posições para manter o fluxo contínuo
  if (xTruck > width) xTruck = 50;
  if (xPlane < 0) xPlane = 550;
}

// Ao clicar, novos elementos aparecem para enriquecer a cena
function mousePressed() {
  fill(255, 0, 0);
  ellipse(mouseX, mouseY, 20, 20); // Simboliza frutas, animais ou interações acontecendo
}
